# 示例 CNN 代码
print('CNN model running')