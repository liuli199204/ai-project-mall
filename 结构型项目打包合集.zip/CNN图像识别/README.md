# CNN 图像识别
使用 PyTorch 训练手写数字识别模型。