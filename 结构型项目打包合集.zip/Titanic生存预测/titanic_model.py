# 示例模型代码
print('Titanic model running')