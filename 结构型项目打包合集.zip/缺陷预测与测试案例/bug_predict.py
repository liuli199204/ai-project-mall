# 缺陷预测示例代码
print('Bug prediction model')